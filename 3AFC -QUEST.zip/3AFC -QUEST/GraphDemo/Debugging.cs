﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraphDemo
{
    public partial class Debugging : Form
    {
        public Debugging()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DomainUpDown.DomainUpDownItemCollection collection = this.domainUpDown1.Items;
            collection.Add("Vertical");
            collection.Add("Horizontal");
            collection.Add("Diagonal1");
            collection.Add("Diagonal2");

            this.domainUpDown1.Text = "Vertical";
        }

        private void wavelengthBox_TextChanged(object sender, EventArgs e)
        {
            if (wavelengthBox.Text != "")
                Inputs.debugWavelength = Convert.ToInt32(wavelengthBox.Text)* 1e-9;
        }

        private void contrastBox_TextChanged(object sender, EventArgs e)
        {
            if (contrastBox.Text != "")
                Inputs.debugContrast = Convert.ToDouble(contrastBox.Text);
        }

        private void SFBox_TextChanged(object sender, EventArgs e)
        {
            if (SFBox.Text != "")
                Inputs.debugSpatialFrequency = Convert.ToInt32(SFBox.Text);
        }

        private void btnPlot_Click(object sender, EventArgs e)
        {
            Inputs.x = ImageLib.meshGridColumns();
            Inputs.y = ImageLib.meshGridLines();
            Inputs.md = Math.Round(0.566 * Inputs.debugWavelength * 1e9 - 101.44) / 255;
            Inputs.k = 2 * Math.PI / Inputs.debugWavelength;
            Inputs.M1 = (int)((-232.31 * Math.Pow(Inputs.debugContrast, 3) + 383.74 * Math.Pow(Inputs.debugContrast, 2) - 270.86 * Inputs.debugContrast + 248.79) * Inputs.md);
            Inputs.M2 = 255 * Inputs.md - Inputs.M1;
            ImageCreation imgcreat = new ImageCreation(); //create the object that will be responsible to calculate the images
            Inputs.shift = (Inputs.debugSpatialFrequency * 180 * Inputs.debugWavelength * 1e3 / Inputs.Mx / Math.PI) / 2; // calculating the fixed information for the next franges
            Inputs.whatTrue = 4;
            switch (this.domainUpDown1.Text)
            {
                case "Horizontal":
                    Inputs.angle1 = 0;
                    break;
                case "Vertical":
                    Inputs.angle1 = 90;
                    break;
                case "Diagonal1":
                    Inputs.angle1 = 135;
                    break;
                case "Diagonal2":
                    Inputs.angle1 = 45;
                    break;
            }
            double[] g1 = ImageLib.multiplyMatrixSub();
            double[] g2 = ImageLib.multiplyMatrixSum();
            Inputs.grL0 = ImageLib.wrapTo2Pi(g1, 1080, 1920);
            Inputs.grR0 = ImageLib.wrapTo2Pi(g2, 1080, 1920);
            Inputs.maxGrL[3] = ImageLib.findMax(Inputs.grL0);
            Inputs.maxGrR[3] = ImageLib.findMax(Inputs.grR0);
            //Inputs.rndPattern = ImageLib.randomPattern();
            Inputs.chkrBrdPattern = ImageLib.checkerBoardPattern();
            imgcreat.calculateFrames();
            Inputs.debugFramesShow = true;
        }

    }
}
