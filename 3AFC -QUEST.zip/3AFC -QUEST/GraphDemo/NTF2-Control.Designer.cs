﻿namespace GraphDemo
{
    partial class GraphDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SFLabel = new System.Windows.Forms.Label();
            this.EccentricityLabel = new System.Windows.Forms.Label();
            this.chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnPlot = new System.Windows.Forms.Button();
            this.SFBox = new System.Windows.Forms.TextBox();
            this.EccentricityBox = new System.Windows.Forms.TextBox();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.NameLabel = new System.Windows.Forms.Label();
            this.trialBox = new System.Windows.Forms.TextBox();
            this.contrastAtualBox = new System.Windows.Forms.TextBox();
            this.caseBox = new System.Windows.Forms.TextBox();
            this.answerBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.prompt = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.trialsBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.backgroundBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.debugButton = new System.Windows.Forms.Button();
            this.wavelengthBox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(981, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(93, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // SFLabel
            // 
            this.SFLabel.AutoSize = true;
            this.SFLabel.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.SFLabel.Location = new System.Drawing.Point(12, 78);
            this.SFLabel.Name = "SFLabel";
            this.SFLabel.Size = new System.Drawing.Size(173, 23);
            this.SFLabel.TabIndex = 2;
            this.SFLabel.Text = "SPATIAL FREQUENCY:";
            // 
            // EccentricityLabel
            // 
            this.EccentricityLabel.AutoSize = true;
            this.EccentricityLabel.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.EccentricityLabel.Location = new System.Drawing.Point(12, 124);
            this.EccentricityLabel.Name = "EccentricityLabel";
            this.EccentricityLabel.Size = new System.Drawing.Size(123, 23);
            this.EccentricityLabel.TabIndex = 4;
            this.EccentricityLabel.Text = "ECCENTRICITY:";
            // 
            // chart
            // 
            this.chart.BackColor = System.Drawing.Color.Transparent;
            this.chart.BorderlineColor = System.Drawing.Color.Black;
            chartArea1.Name = "ChartArea1";
            this.chart.ChartAreas.Add(chartArea1);
            legend1.AutoFitMinFontSize = 12;
            legend1.Name = "Legend1";
            this.chart.Legends.Add(legend1);
            this.chart.Location = new System.Drawing.Point(373, 179);
            this.chart.Name = "chart";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart.Series.Add(series1);
            this.chart.Size = new System.Drawing.Size(586, 342);
            this.chart.TabIndex = 5;
            this.chart.Text = "chart1";
            this.chart.Visible = false;
            // 
            // btnPlot
            // 
            this.btnPlot.BackColor = System.Drawing.Color.Lime;
            this.btnPlot.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.btnPlot.Location = new System.Drawing.Point(93, 550);
            this.btnPlot.Name = "btnPlot";
            this.btnPlot.Size = new System.Drawing.Size(113, 53);
            this.btnPlot.TabIndex = 6;
            this.btnPlot.Text = "START";
            this.btnPlot.UseVisualStyleBackColor = false;
            this.btnPlot.Click += new System.EventHandler(this.btnPlot_Click);
            // 
            // SFBox
            // 
            this.SFBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.SFBox.Location = new System.Drawing.Point(204, 81);
            this.SFBox.Name = "SFBox";
            this.SFBox.Size = new System.Drawing.Size(128, 30);
            this.SFBox.TabIndex = 7;
            this.SFBox.TextChanged += new System.EventHandler(this.xBox_TextChanged);
            // 
            // EccentricityBox
            // 
            this.EccentricityBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.EccentricityBox.Location = new System.Drawing.Point(204, 124);
            this.EccentricityBox.Name = "EccentricityBox";
            this.EccentricityBox.Size = new System.Drawing.Size(128, 30);
            this.EccentricityBox.TabIndex = 8;
            this.EccentricityBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // nameBox
            // 
            this.nameBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.nameBox.Location = new System.Drawing.Point(204, 34);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(128, 30);
            this.nameBox.TabIndex = 10;
            this.nameBox.TextChanged += new System.EventHandler(this.nameBox_TextChanged);
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameLabel.Location = new System.Drawing.Point(12, 34);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(132, 23);
            this.NameLabel.TabIndex = 12;
            this.NameLabel.Text = "SUBJECT NAME:";
            // 
            // trialBox
            // 
            this.trialBox.Enabled = false;
            this.trialBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.trialBox.Location = new System.Drawing.Point(204, 363);
            this.trialBox.Name = "trialBox";
            this.trialBox.ReadOnly = true;
            this.trialBox.Size = new System.Drawing.Size(128, 30);
            this.trialBox.TabIndex = 17;
            // 
            // contrastAtualBox
            // 
            this.contrastAtualBox.Enabled = false;
            this.contrastAtualBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.contrastAtualBox.Location = new System.Drawing.Point(204, 407);
            this.contrastAtualBox.Name = "contrastAtualBox";
            this.contrastAtualBox.ReadOnly = true;
            this.contrastAtualBox.Size = new System.Drawing.Size(128, 30);
            this.contrastAtualBox.TabIndex = 18;
            // 
            // caseBox
            // 
            this.caseBox.Enabled = false;
            this.caseBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.caseBox.Location = new System.Drawing.Point(204, 452);
            this.caseBox.Name = "caseBox";
            this.caseBox.ReadOnly = true;
            this.caseBox.Size = new System.Drawing.Size(128, 30);
            this.caseBox.TabIndex = 19;
            // 
            // answerBox
            // 
            this.answerBox.Enabled = false;
            this.answerBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.answerBox.Location = new System.Drawing.Point(204, 497);
            this.answerBox.Name = "answerBox";
            this.answerBox.ReadOnly = true;
            this.answerBox.Size = new System.Drawing.Size(128, 30);
            this.answerBox.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 363);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 23);
            this.label1.TabIndex = 21;
            this.label1.Text = "TRIAL NUMBER:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 407);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 23);
            this.label2.TabIndex = 22;
            this.label2.Text = "CONTRAST: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 452);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 23);
            this.label3.TabIndex = 23;
            this.label3.Text = "DIRECTION:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 497);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 23);
            this.label4.TabIndex = 24;
            this.label4.Text = "LAST ANSWER: ";
            // 
            // prompt
            // 
            this.prompt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.prompt.Enabled = false;
            this.prompt.Font = new System.Drawing.Font("Calibri", 18F);
            this.prompt.Location = new System.Drawing.Point(389, 53);
            this.prompt.Multiline = true;
            this.prompt.Name = "prompt";
            this.prompt.ReadOnly = true;
            this.prompt.Size = new System.Drawing.Size(561, 46);
            this.prompt.TabIndex = 25;
            this.prompt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trialsBox
            // 
            this.trialsBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.trialsBox.Location = new System.Drawing.Point(204, 198);
            this.trialsBox.Name = "trialsBox";
            this.trialsBox.Size = new System.Drawing.Size(128, 30);
            this.trialsBox.TabIndex = 26;
            this.trialsBox.Text = "30";
            this.trialsBox.TextChanged += new System.EventHandler(this.trialsBox_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(167, 23);
            this.label5.TabIndex = 27;
            this.label5.Text = "NUMBER OF TRIALS:";
            // 
            // backgroundBox
            // 
            this.backgroundBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.backgroundBox.Location = new System.Drawing.Point(204, 246);
            this.backgroundBox.Name = "backgroundBox";
            this.backgroundBox.Size = new System.Drawing.Size(128, 30);
            this.backgroundBox.TabIndex = 28;
            this.backgroundBox.Text = "0";
            this.backgroundBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 246);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 23);
            this.label6.TabIndex = 29;
            this.label6.Text = "BACKGROUND:";
            // 
            // debugButton
            // 
            this.debugButton.BackColor = System.Drawing.Color.Orange;
            this.debugButton.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.debugButton.Location = new System.Drawing.Point(846, 573);
            this.debugButton.Name = "debugButton";
            this.debugButton.Size = new System.Drawing.Size(113, 30);
            this.debugButton.TabIndex = 30;
            this.debugButton.Text = "DEBUG";
            this.debugButton.UseVisualStyleBackColor = false;
            this.debugButton.Click += new System.EventHandler(this.debugButton_Click);
            // 
            // wavelengthBox
            // 
            this.wavelengthBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.wavelengthBox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.wavelengthBox.FormattingEnabled = true;
            this.wavelengthBox.Location = new System.Drawing.Point(204, 293);
            this.wavelengthBox.Name = "wavelengthBox";
            this.wavelengthBox.Size = new System.Drawing.Size(128, 21);
            this.wavelengthBox.TabIndex = 31;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 290);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 23);
            this.label7.TabIndex = 32;
            this.label7.Text = "WAVELENGTH:";
            // 
            // GraphDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 612);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.wavelengthBox);
            this.Controls.Add(this.debugButton);
            this.Controls.Add(this.backgroundBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.trialsBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.prompt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.answerBox);
            this.Controls.Add(this.caseBox);
            this.Controls.Add(this.contrastAtualBox);
            this.Controls.Add(this.trialBox);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.EccentricityBox);
            this.Controls.Add(this.SFBox);
            this.Controls.Add(this.btnPlot);
            this.Controls.Add(this.chart);
            this.Controls.Add(this.EccentricityLabel);
            this.Controls.Add(this.SFLabel);
            this.Controls.Add(this.menuStrip1);
            this.KeyPreview = true;
            this.Location = new System.Drawing.Point(150, 120);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "GraphDemo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "NTF2-Control";
            this.Load += new System.EventHandler(this.GraphDemo_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Label SFLabel;
        private System.Windows.Forms.Label EccentricityLabel;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart;
        private System.Windows.Forms.Button btnPlot;
        private System.Windows.Forms.TextBox SFBox;
        private System.Windows.Forms.TextBox EccentricityBox;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.TextBox trialBox;
        private System.Windows.Forms.TextBox contrastAtualBox;
        private System.Windows.Forms.TextBox caseBox;
        private System.Windows.Forms.TextBox answerBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox prompt;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.TextBox trialsBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox backgroundBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button debugButton;
        private System.Windows.Forms.ComboBox wavelengthBox;
        private System.Windows.Forms.Label label7;
    }
}

