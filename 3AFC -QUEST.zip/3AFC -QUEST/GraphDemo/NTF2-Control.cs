﻿using GraphDemo.QUEST;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MathNet.Numerics.RootFinding;
using System.Windows.Input;
using GemBox.Spreadsheet;
using System.ComponentModel.Design.Serialization;

namespace GraphDemo
{
    public partial class GraphDemo : Form
    {
        public Boolean PlotPressed;
        Read rr;
        public static int aux = 0;
        public int spatialFrequency = 0;
        public string eccentricity;
        public string name;
        public int initial;

        public GraphDemo()
        {
            InitializeComponent();
            Inputs.tGuess = 1; //guess the start point
            Inputs.tGuessSd = 1.5; //guess the Standard Deviation
            Inputs.startPoint = 12;
            Inputs.numberOfTrials = Convert.ToInt32(trialsBox.Text);
            Inputs.contrastBackground = Convert.ToInt32(backgroundBox.Text);

            ImageCreation imgcreat = new ImageCreation(); //create the object that will be responsible to calculate the images
            preCalculationBackground(imgcreat); // pre-calculation of some variables to avoid losing time in each trial by unuseful calculations.
            Inputs.stdShow = true;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void readPlot()
        {

            try
            {
                rr = new Read();
                string[] header = rr.get_Header();
                List<string> lX = new List<string>();
                List<string> lY = new List<string>();
                for (int i = 0; i < header.Length; i++)
                {
                    lX.Add(header[i]); lY.Add(header[i]);
                }
            }
            catch (Exception err)
            {
                //Inform the user if we can't read the file
                MessageBox.Show(err.Message);
            }
            Plot pl = new Plot(rr, chart);

        }

        private void btnPlot_Click(object sender, EventArgs e)
        {
            PlotPressed = true;

            if (spatialFrequency != 0 && eccentricity != null) RunQUEST();

        }


        public void RunQUEST()
        {
            SelectWavelength(this.wavelengthBox.Text);
            readGrayLevelValues();
            prompt.Text = "Loading...";
            this.Update();
            System.Random rnd = new System.Random();

            StructTemplate QUEST = new StructTemplate();
            QUEST = QUESTLib.QUESTCreate(QUEST); //create the QUEST procedure structure
            ImageCreation imgcreat = new ImageCreation(); //create the object that will be responsible to calculate the images

            QUEST.name = name;
            QUEST.eccentricity = eccentricity;
            QUEST.spatialFrequency = spatialFrequency;
            Inputs.spatialFrequency = spatialFrequency;
            QUEST.pdf2 = new double[33, QUEST.pdf.Length];

            preCalculation(imgcreat); // pre-calculation of some variables to avoid losing time in each trial by unuseful calculations.

            Inputs.momentIntensity = Inputs.startPoint;
            Inputs.relativContrast = Inputs.momentIntensity * (100 - Inputs.contrastBackground) / 100;

            QUESTLib.SaveSetup(QUEST);
            trialBox.Text = "1" + " / " + Convert.ToString(Inputs.numberOfTrials);
            contrastAtualBox.Text = Convert.ToString(Math.Round(Inputs.relativContrast, 2));

            Thread t5 = ThreadKeyboardReader();

            t5.SetApartmentState(ApartmentState.STA);

            t5.Start();

            Inputs.inputKey = " ";
            Inputs.waitingAnswer = true;

            prompt.Text = "Press Esc to start";
            this.Update();

            Inputs.escReaded = false;
            while (!Inputs.escReaded) ;
            Inputs.waitingAnswer = false;

            ContrastRealimentation();
            while (PlotPressed)
            {
                for (QUEST.trialCount = 1; QUEST.trialCount <= Inputs.numberOfTrials; QUEST.trialCount++)
                {   //calculating the variables M1 and M2 to transform the contrast value into a byte

                    prompt.Text = "Running  -  Esc to abort";
                    this.Update();

                    if (Inputs.whatTrue != 5) //in the case the user pressed "esc" to escape the program.
                    {

                        savePdf(QUEST);
                        guessDirection(); // choose one of the 2 possible directions (vertical, horizontal, diagonal 1 and diadonal 2).
                        //Inputs.rndPattern = ImageLib.randomPattern(); // calculate the randon pattern
                        Inputs.chkrBrdPattern = ImageLib.checkerBoardPattern();
                        imgcreat.calculateFrames(); //calculate the image in the defined contrast
                        Inputs.framesShow = true; // show the frame that was calculated in the line above (external program)
                        while (Inputs.framesShow) ; // wait until the frame was already showed (external program)
                        QUEST = QUESTLib.getAnswer(QUEST); // get the answer from the user (which direction he saw the fringes)
                        if (Inputs.momentIntensity <= 0) Inputs.momentIntensity = 0.00001; // because log10 of 0
                        QUEST = QUESTLib.QuestUpdate(QUEST, Math.Log10(Inputs.momentIntensity / 100), Inputs.answer); //update the QUEST algoritm with the new information
                        double auxx = Math.Pow(10, QUESTLib.QuestMean(QUEST)) * 100; //calculate the contrast intensity in the next trial.
                        while ((Inputs.answer && (auxx > Inputs.momentIntensity)) || (!Inputs.answer && (Math.Pow(10, QUESTLib.QuestMean(QUEST)) * 100) < Inputs.momentIntensity)) // avoid errors due to the fact of we are using always different outputs as trials
                        {
                            QUEST = QUESTLib.QuestUpdate(QUEST, Math.Log10(Inputs.momentIntensity / 100), Inputs.answer); //update the QUEST algoritm with the new information
                            auxx = Math.Pow(10, QUESTLib.QuestMean(QUEST)) * 100;
                        }
                        Inputs.momentIntensity = auxx;
                        //Inputs.momentIntensity = QUESTLib.StairCase(QUEST);
                        if (QUEST.trialCount == 1) this.chart.Visible = true;
                        if (Inputs.answer) answerBox.Text = "True"; //print information in the interface
                        else answerBox.Text = "False";
                        if (Inputs.momentIntensity < 0) Inputs.momentIntensity = 0;
                        if (Inputs.momentIntensity > 12) Inputs.momentIntensity = 12;

                        ContrastRealimentation();

                        QUESTLib.SaveDataPlot(QUEST); // save the data in the csv files

                        if (QUEST.trialCount < Inputs.numberOfTrials)
                        {
                            trialBox.Text = (Convert.ToString(QUEST.trialCount + 1) + " / " + Convert.ToString(Inputs.numberOfTrials));
                            //contrastAtualBox.Text = (Convert.ToString(Math.Log10(Inputs.momentIntensity/100)));
                            contrastAtualBox.Text = (Convert.ToString(Math.Round(Inputs.relativContrast, 2)));
                            readPlot(); // read the information to plot in the interface
                        }
                    }
                }
                saveGraphs(QUEST);
                if (QUEST.trialCount < Inputs.numberOfTrials) readPlot();
                if (QUEST.trialCount-1 == Inputs.numberOfTrials) QUESTLib.SaveData(QUEST);
                this.Update();
                Console.Beep();
                Console.Beep(800, 1500);
                prompt.Text = "Exit - 1    Continue - 0: ";
                this.Update();
                Inputs.inputKeyAgain = -1; //set the key that will be used to restart the program or exit
                Inputs.waitingAnswerAgain = true;
                while (Inputs.inputKeyAgain != 0 && Inputs.inputKeyAgain != 1) ;
                this.chart.Visible = false;
                this.Update();
                Inputs.waitingAnswerAgain = false;
                if (Inputs.inputKeyAgain == 0) //set the variables to restart the program without exit the program
                {
                    QUEST = null;
                    QUEST = new StructTemplate();
                    QUEST = QUESTLib.QUESTCreate(QUEST);
                    QUEST.name = name;
                    QUEST.eccentricity = eccentricity;
                    QUEST.spatialFrequency = spatialFrequency;
                    Inputs.momentIntensity = Inputs.startPoint;
                    ContrastRealimentation();
                    Inputs.relativContrast = Inputs.momentIntensity * (100 - Inputs.contrastBackground) / 100;
                    trialBox.Text = "1" + " / " + Convert.ToString(Inputs.numberOfTrials);
                    contrastAtualBox.Text = Convert.ToString(Math.Round(Inputs.relativContrast,2));
                    answerBox.Text = " ";
                    QUESTLib.SaveSetup(QUEST);
                    readPlot();
                    this.Update();
                    Inputs.whatTrue = 1;

                    Inputs.inputKey = " ";
                    Inputs.waitingAnswer = true;

                    prompt.Text = "Press Esc to start";
                    this.Update();
                    Inputs.escReaded = false;
                    while (!Inputs.escReaded);
                    Inputs.waitingAnswer = false;
                }
                else
                {
                    PlotPressed = false;
                    t5.Abort();
                    prompt.Clear();
                    QUEST = null;
                }
            }
        }

        

        private void xBox_TextChanged(object sender, EventArgs e)
        {
            if (SFBox.Text != "")
                spatialFrequency = Convert.ToInt32(SFBox.Text);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            eccentricity = EccentricityBox.Text;
        }

        private void nameBox_TextChanged(object sender, EventArgs e)
        {
            name = nameBox.Text;
        }

        private void trialsBox_TextChanged(object sender, EventArgs e)
        {
            if (trialsBox.Text != "")
                Inputs.numberOfTrials = Convert.ToInt32(trialsBox.Text);
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            if (backgroundBox.Text != "")
                Inputs.contrastBackground = Convert.ToInt32(backgroundBox.Text);
        }



        private void guessDirection()
        {
            System.Random rnd = new System.Random();
            int randonValue = rnd.Next(3);
            switch (randonValue)
            {
                case 0:
                    //if the random choice is 0, the image is vertical
                    Inputs.whatTrue = 1;
                    caseBox.Text = "Image 1 - Up";
                    Inputs.angle1 = 1.3;
                    this.Update();

                    break;
                case 1:
                    //if the random choice is 1, the image is diagona 1
                    Inputs.whatTrue = 2;
                    caseBox.Text = "Image 2 - Right";
                    Inputs.angle1 = 136.3;
                    this.Update();

                    break;
                case 2:
                    //if the random choice is 2, the image is horizontal
                    Inputs.whatTrue = 3;
                    caseBox.Text = "Image 3 - Down";
                    Inputs.angle1 = 91.3;
                    this.Update();

                    break;
            }
        }

        private void preCalculationBackground(ImageCreation imgcreat)
        {
            Inputs.x = ImageLib.meshGridColumns();
            Inputs.y = ImageLib.meshGridLines();
            Inputs.md = Math.Round(0.566 * Inputs.wavelength * 1e9 - 101.44) / 255;
            Inputs.k = 2 * Math.PI / Inputs.wavelength;
            Inputs.M1 = (int)((248.69) * Inputs.md);
            Inputs.M2 = 255 * Inputs.md - Inputs.M1;
            //Inputs.rndPattern = ImageLib.randomPattern(); //calculating the random pattern just one time to the background
            Inputs.chkrBrdPattern = ImageLib.checkerBoardPattern();

            Inputs.shift = 0; // calculating the fixed information for the next franges
            Inputs.angle1 = 0;
            double[] g1 = ImageLib.multiplyMatrixSub();
            double[] g2 = ImageLib.multiplyMatrixSum();
            Inputs.grL0 = ImageLib.wrapTo2Pi(g1, 1080, 1920);
            Inputs.grR0 = ImageLib.wrapTo2Pi(g2, 1080, 1920);
            Inputs.maxGrL[0] = ImageLib.findMax(Inputs.grL0);
            Inputs.maxGrR[0] = ImageLib.findMax(Inputs.grR0);
            Inputs.whatTrue = 1;
            imgcreat.calculateFrames();
            Inputs.stdImage[0] = Inputs.image;
        }


            private void preCalculation(ImageCreation imgcreat)
        {
            Inputs.image0 = ImageLib.createImage0();
            Inputs.x = ImageLib.meshGridColumns();
            Inputs.y = ImageLib.meshGridLines();
            Inputs.md = Math.Round(0.566 * Inputs.wavelength * 1e9 - 101.44) / 255;
            Inputs.k = 2 * Math.PI / Inputs.wavelength;
            Inputs.M1 = (int)(0 * Inputs.md);
            Inputs.M2 = 255 * Inputs.md - Inputs.M1;
            //Inputs.rndPattern = ImageLib.randomPattern(); //calculating the random pattern just one time to the background
            Inputs.chkrBrdPattern = ImageLib.checkerBoardPattern();

            Inputs.shift = (Inputs.spatialFrequency * 180 * Inputs.wavelength * 1e3 / Inputs.Mx / Math.PI)/2; // calculating the fixed information for the next franges
            Inputs.angle1 = 1.3;
            double[] g1 = ImageLib.multiplyMatrixSub();
            double[] g2 = ImageLib.multiplyMatrixSum();
            Inputs.grL0 = ImageLib.wrapTo2Pi(g1, 1080, 1920);
            Inputs.grR0 = ImageLib.wrapTo2Pi(g2, 1080, 1920);
            Inputs.maxGrL[0] = ImageLib.findMax(Inputs.grL0);
            Inputs.maxGrR[0] = ImageLib.findMax(Inputs.grR0);
            Inputs.whatTrue = 1;
            imgcreat.calculateFrames();
            Inputs.stdImage[0] = Inputs.image;
            Inputs.angle1 = 136.3;
            g1 = ImageLib.multiplyMatrixSub();
            g2 = ImageLib.multiplyMatrixSum();
            Inputs.grL135 = ImageLib.wrapTo2Pi(g1, 1080, 1920);
            Inputs.grR135 = ImageLib.wrapTo2Pi(g2, 1080, 1920);
            Inputs.maxGrL[1] = ImageLib.findMax(Inputs.grL135);
            Inputs.maxGrR[1] = ImageLib.findMax(Inputs.grR135);
            Inputs.whatTrue = 2;
            imgcreat.calculateFrames();
            Inputs.stdImage[1] = Inputs.image;
            Inputs.angle1 = 91.3;
            g1 = ImageLib.multiplyMatrixSub();
            g2 = ImageLib.multiplyMatrixSum();
            Inputs.grL90 = ImageLib.wrapTo2Pi(g1, 1080, 1920);
            Inputs.grR90 = ImageLib.wrapTo2Pi(g2, 1080, 1920);
            Inputs.maxGrL[2] = ImageLib.findMax(Inputs.grL90);
            Inputs.maxGrR[2] = ImageLib.findMax(Inputs.grR90);
            Inputs.whatTrue = 3;
            imgcreat.calculateFrames();
            Inputs.stdImage[2] = Inputs.image;

        }

        private void ContrastRealimentation()
        {
            if (Inputs.momentIntensity > Inputs.contrasts[Inputs.contrasts.Length - 1])
            {
                Inputs.M1 = Inputs.graylevels[Inputs.contrasts.Length - 1];
                Inputs.M2 = 255 * Inputs.md - Inputs.M1;
                Inputs.momentIntensity = Inputs.contrasts[Inputs.contrasts.Length - 1];
            }
            else if (Inputs.momentIntensity < Inputs.contrasts[0])
            {
                Inputs.M1 = Inputs.graylevels[0];
                Inputs.M2 = 255 * Inputs.md - Inputs.M1;
                Inputs.momentIntensity = Inputs.contrasts[0];
            }
            else
            {
                double auxIntensity = Inputs.momentIntensity;
                for (int i = 0; i < Inputs.graylevels.Length - 1; i++)
                {
                    if (auxIntensity >= Inputs.contrasts[i] && auxIntensity < Inputs.contrasts[i + 1])
                    {
                        if ((Inputs.contrasts[i + 1] - Inputs.momentIntensity) > (Inputs.momentIntensity - Inputs.contrasts[i]))
                        {
                            if (Inputs.M1 == Inputs.graylevels[i] && Inputs.answer)
                            {
                                if ((i - 1) >= 0)
                                {
                                    Inputs.M1 = Inputs.graylevels[i - 1];
                                    Inputs.momentIntensity = Inputs.contrasts[i - 1];
                                }
                                else
                                {
                                    Inputs.M1 = Inputs.graylevels[i];
                                    Inputs.momentIntensity = Inputs.contrasts[i];
                                }
                            }
                            else if (Inputs.M1 == Inputs.graylevels[i] && !Inputs.answer)
                            {
                                
                                Inputs.M1 = Inputs.graylevels[i + 1];
                                Inputs.momentIntensity = Inputs.contrasts[i + 1];
                            }
                            else
                            {
                                Inputs.M1 = Inputs.graylevels[i];
                                Inputs.momentIntensity = Inputs.contrasts[i];
                            }
                            Inputs.M2 = 255 * Inputs.md - Inputs.M1;
                        }
                        else
                        {
                            if (Inputs.M1 == Inputs.graylevels[i + 1] && Inputs.answer)
                            {
                                    Inputs.M1 = Inputs.graylevels[i];
                                    Inputs.momentIntensity = Inputs.contrasts[i];
                            }
                            else if (Inputs.M1 == Inputs.graylevels[i + 1] && !Inputs.answer)
                            {
                                if ((i + 2) < Inputs.graylevels.Length)
                                {
                                    Inputs.M1 = Inputs.graylevels[i + 2];
                                    Inputs.momentIntensity = Inputs.contrasts[i + 2];
                                }
                                else 
                                {
                                    Inputs.M1 = Inputs.graylevels[i + 1];
                                    Inputs.momentIntensity = Inputs.contrasts[i + 1];
                                }
                            }
                            else
                            {
                                Inputs.M1 = Inputs.graylevels[i + 1];
                                Inputs.momentIntensity = Inputs.contrasts[i + 1];
                            }
                            Inputs.M2 = 255 * Inputs.md - Inputs.M1;
                        }
                    }
                }
            }
            Inputs.relativContrast = Inputs.momentIntensity * (100 - Inputs.contrastBackground) / 100;
        }

        public static Thread ThreadKeyboardReader()
        {
            Thread t = new Thread(() =>
            {
                while (true)
                {
                    if (!Inputs.escReaded)
                    {
                        if ((Keyboard.GetKeyStates(Key.Escape) & KeyStates.Down) > 0) Inputs.escReaded = true;
                    }
                    if (Inputs.waitingAnswer == true)
                    {
                        if ((Keyboard.GetKeyStates(Key.Right) & KeyStates.Down) > 0)
                            Inputs.inputKey = "Right";
                        if ((Keyboard.GetKeyStates(Key.Up) & KeyStates.Down) > 0)
                            Inputs.inputKey = "Up";
                        if ((Keyboard.GetKeyStates(Key.Down) & KeyStates.Down) > 0)
                            Inputs.inputKey = "Down";
                        if ((Keyboard.GetKeyStates(Key.Escape) & KeyStates.Down) > 0)
                            Inputs.inputKey = "Escape";
                    }
                    if (Inputs.waitingAnswerAgain == true)
                    {
                        if (((Keyboard.GetKeyStates(Key.D1) & KeyStates.Down) > 0) || ((Keyboard.GetKeyStates(Key.NumPad1) & KeyStates.Down) > 0))
                        {
                            Inputs.inputKeyAgain = 1;
                        }
                        if (((Keyboard.GetKeyStates(Key.D0) & KeyStates.Down) > 0) || ((Keyboard.GetKeyStates(Key.NumPad0) & KeyStates.Down) > 0))
                        {
                            Inputs.inputKeyAgain = 0;
                        }
                    }
                }
            });
            return t;
        }

        private void debugButton_Click(object sender, EventArgs e)
        {
            Thread t5 = new Thread(() =>
            {
                Application.Run(new Debugging());
            });

            t5.Start();
        }


        private void GraphDemo_Load(object sender, EventArgs e)
        {
            ComboBox.ObjectCollection collection = this.wavelengthBox.Items;
            collection.Add("GREEN");
            collection.Add("BLUE");
            collection.Add("RED");
            collection.Add("WHITE");

            this.wavelengthBox.Text = "GREEN";
        }

        private void SelectWavelength(string color)
        {
            switch (color)
            {
                case "GREEN":
                    Inputs.wavelength = 532e-9;
                    Inputs.wavelengthColor = "Green";
                    break;
                case "BLUE":
                    Inputs.wavelength = 450e-9;
                    Inputs.wavelengthColor = "Blue";
                    break;
                case "RED":
                    Inputs.wavelength = 630e-9;
                    Inputs.wavelengthColor = "Red";
                    break;
                case "WHITE":
                    Inputs.wavelength = 532e-9;
                    //Inputs.wavelength = ;
                    Inputs.wavelengthColor = "White";
                    break;
            }
        }
        private void readGrayLevelValues()
        {
            GrayLevelReader rr = new GrayLevelReader();
            float[,] data = rr.get_Data();
            int nLines = rr.get_nLines();
            Inputs.graylevels = new int[nLines];
            Inputs.contrasts = new double[nLines];
            for (int i = 0; i < nLines; i++)
            {
                Inputs.graylevels[i] = (int)data[i, 0];
                Inputs.contrasts[i] = data[i, 1] * 100;
            }
        }

        private void savePdf(StructTemplate QUEST)
        {
            QUEST.pdf2 = new double[33, QUEST.pdf.Length];
            for (int i = 0; i < QUEST.pdf.Length; i++)
            {
                QUEST.pdf2[QUEST.trialCount, i] = QUEST.pdf[i];
            }
        }

        private void saveGraphs(StructTemplate QUEST)
        {
            SpreadsheetInfo.SetLicense("FREE-LIMITED-KEY");

            var workbook = new ExcelFile();
            string date = DateTime.UtcNow.ToString("MM-dd-yyyy");
            var worksheet = workbook.Worksheets.Add("pdf");
            for(int i = 0; i < 30; i++)
            {
                worksheet.Cells[i, 0].Value = i;
                for (int j = 0; j < QUEST.pdf.Length; j++)
                {
                    worksheet.Cells[i, j + 1].Value = QUEST.pdf2[i,j];
                }
            }
            

            var root = date ;
            
            if (!Directory.Exists(root))
            {
                Directory.CreateDirectory(root);
            }

            workbook.Save(root + "\\" + Convert.ToString(QUEST.trialCount) + "profile.xlsx");
        }





    }
}