﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphDemo.QUEST
{
    class Function
    {
        static public int[] CreateRange(int StartingPoint, int EndingPoint, int div = 1)
        {
            /// Creates a list from one point to other in double.
            int Steps = EndingPoint - StartingPoint;
            IEnumerable<int> a = Enumerable.Range(StartingPoint, Steps);
            int[] d = new int[Steps];
            int Ind = 0;
            foreach (int num in a)
            {
                d[Ind] = num / div;
                Ind++;
            };
            return d;
        }
        static public double Sum(double[] array)
        {
            double d = 0;
            foreach (double a in array)
            {
                d += a;
            }
            return d;
        }

        static public double[] Diff(double[] p2)
        {
            double[] d = new double[p2.Length - 1];
            for(int i = 0; i < d.Length; i++)
            {
                d[i] = p2[i + 1] - p2[i];
            }
            return d;
        }

        static public double[] Find(double[] d2)
        {
            List<double> dd = new List<double>();

            for (int i = 0; i < d2.Length; i++)
            {
                if (d2[i] != 0)
                {
                    dd.Add(i);
                }
            }

            return dd.ToArray();
        }

        static public double[,] Fliplr(double [] p2)
        {
            double[,] s2 = new double[p2.Length, p2.Length];

            for(int i=0; i < p2.Length; i++)
            {
                s2[0, i] = 1 - p2[p2.Length - (i + 1)];
                s2[1, i] = p2[p2.Length - (i + 1)];
            }

            return s2;
        }
    }
}
