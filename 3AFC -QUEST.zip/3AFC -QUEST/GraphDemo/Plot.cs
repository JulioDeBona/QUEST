﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace GraphDemo
{
    class Plot
    {
        public Plot(Read rr, Chart chart)
        {

            int indX = 0;
            int indY = 1;
            float[,] data = rr.get_Data();
            int nLines = rr.get_nLines();
            int nColumns = rr.get_nColumns();
            string[] header = rr.get_Header();


            chart.Series.Clear(); //ensure that the chart is empty
            chart.Series.Add("Series0");
            chart.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart.Series[0].MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            chart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chart.ChartAreas[0].AxisX.LabelStyle.Format = "{F0}";
            chart.ChartAreas[0].AxisY.LabelStyle.Format = "{F0}";
            chart.ChartAreas[0].AxisX.Minimum = 1;
            chart.ChartAreas[0].AxisY.Maximum = 12 - (Inputs.contrastBackground);
            chart.ChartAreas[0].AxisY.Minimum = 0;
            chart.ChartAreas[0].AxisX.Title = header[indX];
            chart.ChartAreas[0].AxisY.Title = header[indY];
            chart.ChartAreas[0].AxisX.TitleFont = new Font("Arial", 14);
            chart.ChartAreas[0].AxisY.TitleFont = new Font("Arial", 14);
            chart.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Arial", 12);
            chart.ChartAreas[0].AxisY.LabelStyle.Font = new Font("Arial", 12);
            chart.Legends.Clear();
            for (int j = 0; j < nLines; j++)
            {
                chart.Series[0].Points.AddXY(data[j, indX], data[j, indY]);
            }
        }
    }
}
