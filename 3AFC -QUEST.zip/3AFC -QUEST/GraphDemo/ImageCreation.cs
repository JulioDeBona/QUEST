﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GraphDemo
{
    public class ImageCreation
    {
        public void calculateFrames()
        {
            //var watch = System.Diagnostics.Stopwatch.StartNew();
            double[] grL = ChooseGrL();
            double[] grR = ChooseGrR();
            double grLFactor = 1 / Inputs.maxGrL[Inputs.whatTrue - 1] * Inputs.M1;
            double grRFactor = 1 / Inputs.maxGrR[Inputs.whatTrue - 1] * Inputs.M2;
            grL = ImageLib.exchange(grL, grLFactor, grR, grRFactor);
            byte[] mask = ImageLib.toByte(grL);
            Inputs.image = ImageLib.imageFill(mask);
            /*watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            Console.WriteLine(elapsedMs);*/
        }

        private double [] ChooseGrL() //get the value the was previously calculated
        {
            switch (Inputs.whatTrue)
            {
                case 1:
                    return Inputs.grL0;
                case 2:
                    return Inputs.grL135;
                case 3:
                    return Inputs.grL90;
                default:
                    return null;
            }
        }

        private double[] ChooseGrR() //get the value the was previously calculated
        {
            switch (Inputs.whatTrue)
            {
                case 1:
                    return Inputs.grR0;
                case 2:
                    return Inputs.grR135;
                case 3:
                    return Inputs.grR90;
                default:
                    return null;
            }
        }


        /*var watch = System.Diagnostics.Stopwatch.StartNew();
           watch.Stop();
           var elapsedMs = watch.ElapsedMilliseconds;
           Console.WriteLine(elapsedMs);*/

    }
}
