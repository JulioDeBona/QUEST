﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphDemo
{
    public static class Inputs
    {

        public static double[] stairCaseSteps = { 2, 2, 1, 1, 1, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.1, 0.1, 0.1, 0.1, 0.1};

        public static string inputKey;
        public static bool waitingAnswer = false;
        public static int inputKeyAgain;
        public static bool waitingAnswerAgain = false;
        public static int whatTrue;
        public static bool answer;
        public static int AnswerTime;
        public static int auxThreads;

        public static string wavelengthColor;
        public static int[] graylevels;
        public static double[] contrasts;
        public static int numberOfTrials;
        public static bool escReaded = false;
        public static double contrastBackground;
        public static double momentIntensity;
        public static double relativContrast;
        public static double spatialFrequency;
        public static double tGuess;
        public static double tGuessSd;
        public static double startPoint;
        public static float nafc;
        public static int images;
        public static int imagestrue;
        public static int imagesfalse;
        public static double L = 0.01536;
        public static double H = 0.00864;
        public static int Nx = 1920;
        public static double[] x;
        public static double[] y;
        public static double f = 750;
        public static double wavelength = 532e-9;
        public static double k;
        public static double cx = 3;
        public static double cy = 3;
        public static double Mx = 0.4;
        public static double md;
        public static double M1;
        public static double M2;
        public static double shift;
        public static double angle1 = 0;
        public static double xL;
        public static Bitmap image0;
        public static Bitmap image;
        public static Bitmap[] stdImage = new Bitmap[4];
        public static int stdImages;
        //public static bool[] rndPattern;
        public static bool[] chkrBrdPattern;
        public static double[] grR0;
        public static double[] grL0;
        public static double[] grR45;
        public static double[] grL45;
        public static double[] grR90;
        public static double[] grL90;
        public static double[] grR135;
        public static double[] grL135;
        public static double[] maxGrL = new double[4];
        public static double[] maxGrR = new double[4];
        public static double grRFactor;
        public static bool framesShow;
        public static bool stdShow;
        public static bool debugFramesShow;


        public static double debugWavelength;
        public static double debugContrast;
        public static double debugDirection;
        public static double debugSpatialFrequency;
    }
}
