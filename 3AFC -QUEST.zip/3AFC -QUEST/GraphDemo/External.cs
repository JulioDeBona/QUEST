﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraphDemo
{
    public partial class External : Form
    {
        public External()
        {
            InitializeComponent();
        }


        private void External_Load(object sender, EventArgs e)
        {
            this.DoubleBuffered = true;
            this.Paint += new PaintEventHandler(External_Paint);
        }


        private void External_Paint(object sender, PaintEventArgs e)
        {
            while (true)
            {
                if (Inputs.framesShow) printFrames();
                if (Inputs.debugFramesShow) printDebugFrames();
                if (Inputs.stdShow) printStd();
            }
        }

        private void printStd()
        {
            pictureBox1.Image = Inputs.stdImage[0];
            pictureBox1.Update();
            Inputs.stdShow = false;
        }

        private void printDebugFrames()
        {
            pictureBox1.Image = Inputs.image;
            pictureBox1.Update();
        }

        private void printFrames()
        {
            pictureBox1.Image = Inputs.image0;
            pictureBox1.Update();
            Thread.Sleep(200);
            pictureBox1.Image = Inputs.stdImage[Inputs.whatTrue - 1];
            pictureBox1.Update();
            Console.Beep();
            pictureBox1.Image = Inputs.image;
            pictureBox1.Update();
            Thread.Sleep(300);
            pictureBox1.Image = Inputs.stdImage[Inputs.whatTrue-1];
            pictureBox1.Update();
            Inputs.framesShow = false;
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Refresh();

        }
    }
}