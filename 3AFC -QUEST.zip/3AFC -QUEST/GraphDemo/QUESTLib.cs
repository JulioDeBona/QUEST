﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace GraphDemo.QUEST
{
    class QUESTLib
    {
        static public StructTemplate QUESTCreate(StructTemplate QUEST)
        {
            Inputs.nafc = 3; // N Alternative Forced Choice
            QUEST.grain = 0.1;
            QUEST.dim = 500;
            QUEST.updatePdf = true;
            QUEST.warnPdf = true;
            QUEST.normalizePdf = true;
            //QUEST.pThreshold = 0.9;
            QUEST.beta = 2;
            QUEST.delta = 0.1;
            QUEST.gamma = 1 / (Inputs.nafc);
            QUEST.xThreshold = 0.1; //took from MATLAB
            QUEST.tGuess = Math.Log10(Inputs.tGuess/100);
            QUEST.tGuessSd = Inputs.tGuessSd;


            QUEST.i = Function.CreateRange(Convert.ToInt32(-QUEST.dim / 2), Convert.ToInt32(QUEST.dim / 2 + 1));
            QUEST.x = new double[QUEST.i.Length];
            QUEST.pdf = new double[QUEST.i.Length];
            QUEST.i2 = Function.CreateRange(Convert.ToInt32(-QUEST.dim), Convert.ToInt32(QUEST.dim + 1));
            QUEST.x2 = new double[QUEST.i2.Length];
            QUEST.p2 = new double[QUEST.i2.Length];

            for (int i = 0; i < QUEST.i.Length; i++)
            {
                QUEST.x[i] = QUEST.i[i] * QUEST.grain;
                QUEST.pdf[i] = Math.Exp(-0.5 * (QUEST.x[i] / QUEST.tGuessSd) * (QUEST.x[i] / QUEST.tGuessSd));
            }

            double sumPdf = Function.Sum(QUEST.pdf);
            for (int i = 0; i < QUEST.i.Length; i++) QUEST.pdf[i] /= sumPdf;

            for (int i = 0; i < QUEST.i2.Length; i++)
            {
                QUEST.x2[i] = Math.Round(QUEST.i2[i] * QUEST.grain, 1);
                double aux0 = (QUEST.beta * (QUEST.x2[i] + QUEST.xThreshold));
                double aux1 = Math.Pow(10, aux0);
                double aux2 = Math.Exp(-aux1);
                QUEST.p2[i] = QUEST.delta * QUEST.gamma + (1 - QUEST.delta) * (1 - (1 - QUEST.gamma) * aux2);
            }

            QUEST.s2 = Function.Fliplr(QUEST.p2);
            QUEST.intensity = new double[10000];
            QUEST.response = new bool[10000];
            double pL = QUEST.p2[0];
            double pH = QUEST.p2[QUEST.p2.Length - 1];
            double eps = Math.Pow(2, -52);
            double pE = pH * Math.Log(pH + eps) - pL * Math.Log(pL + eps) + (1 - pH + eps) * Math.Log(1 - pH + eps) - (1 - pL + eps) * Math.Log(1 - pL + eps);
            double pE2 = 1 / (1 + Math.Exp(pE / (pL - pH)));
            QUEST.quantileOrder = (pE2 - pL) / (pH - pL);

            QUEST.normalizePdf = true;

            return QUEST;
        }



        static public double QuestMean(StructTemplate QUEST) // used to update the contrast after updating the QUEST procedure with new information
        {
            double intensity;
            double[] PdfxX = new double[QUEST.pdf.Length];
            for (int i = 0; i < QUEST.pdf.Length; i++)
            {
                PdfxX[i] = QUEST.pdf[i] * QUEST.x[i];
            }
            double sumPdf = Function.Sum(QUEST.pdf);
            double sumPdfxX = Function.Sum(PdfxX);
            intensity = QUEST.tGuess + sumPdfxX / sumPdf;
            return intensity;
        }



        static public StructTemplate QuestUpdate(StructTemplate QUEST, double intensity, bool response) // update the QUEST procedure with the new data
        {
            int[] ii = new int[QUEST.pdf.Length];
            if (QUEST.updatePdf)
            {
                int auxResponse;
                for (int i = 0; i < ii.Length; i++) ii[i] = QUEST.pdf.Length + QUEST.i[i] - (int)Math.Round((intensity - QUEST.tGuess) / QUEST.grain);
                if (response == true) auxResponse = 1;
                else auxResponse = 0;
                for (int i = 0; i < QUEST.pdf.Length; i++) QUEST.pdf[i] = QUEST.pdf[i] * QUEST.s2[auxResponse, ii[i]];
                double sumPdf = Function.Sum(QUEST.pdf);
                if (QUEST.normalizePdf)
                {
                    for (int i = 0; i < QUEST.pdf.Length; i++) QUEST.pdf[i] = QUEST.pdf[i] / sumPdf;
                }
            }

            QUEST.intensity[QUEST.trialCount] = intensity;
            QUEST.response[QUEST.trialCount] = response;

            return QUEST;
        }

        public static void Exit()
        {
            Inputs.whatTrue = 5;
        }

        public static StructTemplate getAnswer(StructTemplate QUEST)
        {
            //Creating a new thread to wait the answer
            Thread t2 = WaitAnswer();
            t2.Start();
            Inputs.auxThreads = -1;

            //Using a extra thread to count time while the answer is expected
            Thread t1 = WaitTimeout();
            t1.Start();
            //While there is no answer from the time thread or the answer thread, stay here
            while (Inputs.auxThreads == -1)
            {
            }
            // Then restart the stopped Thread
            if (Inputs.inputKey == "Escape")
            {
                Exit();
            }

            if (QUEST.trialCount == 1) SaveSetupPlot(QUEST);/*
            KeyEventArgs e;
            if (String.Equals(Convert.ToString(e.KeyCode), "Right"))
                Inputs.inputKey = "Right";*/
            //Compare the answer from the user with the right answer ploted.
            switch (Inputs.inputKey)
            {
                case "Up":
                    if (Inputs.whatTrue == 1) Inputs.answer = true;
                    else Inputs.answer = false;
                    break;
                case "Right":
                    if (Inputs.whatTrue == 2) Inputs.answer = true;
                    else Inputs.answer = false;
                    break;
                case "Down":
                    if (Inputs.whatTrue == 3) Inputs.answer = true;
                    else Inputs.answer = false;
                    break;
                default:
                    Inputs.answer = false;
                    break;
            }
            t1.Abort();
            t1 = null;
            t2.Abort();
            t2 = null;

            //end the threads and save the data
            SaveDataPreview(QUEST);
            SaveDataPreviewXml(QUEST);
            return QUEST;
        }

        public static Thread WaitAnswer()
        {
            Thread t = new Thread(() =>
            {
                Inputs.waitingAnswer = true;
                Inputs.inputKey = " ";
                while ((Inputs.inputKey != "Left") && (Inputs.inputKey != "Right") && (Inputs.inputKey != "Up") && (Inputs.inputKey != "Down") && (Inputs.inputKey != "Escape")) ;
                //while ((Inputs.inputKey != "Left") && (Inputs.inputKey != "Right") && (Inputs.inputKey != "Escape")) ;
                Inputs.waitingAnswer = false;
                Inputs.auxThreads = 0;
                Console.Beep(800, 100);

            });
            return t;
        }

        public static Thread WaitTimeout()
        {
            Thread t = new Thread(() =>
            {
                int numberOfDeciseconds = 0;
                while (numberOfDeciseconds < 1000)
                {
                    Thread.Sleep(100);
                    numberOfDeciseconds++;
                    Inputs.AnswerTime = numberOfDeciseconds;
                }
                Console.Beep(800, 100);
                if (Inputs.whatTrue == 1) Inputs.inputKey = "Right";
                else Inputs.inputKey = "Up";
                Inputs.auxThreads = 0;

            });
            return t;
        }

        public static void SaveDataPreviewXml(StructTemplate QUEST)
        {
            var csv = new StringBuilder();
            var first = QUEST.trialCount;
            var second = Inputs.relativContrast;
            int third;
            if (Inputs.answer) third = 1;
            else third = 0;
            var fourth = Inputs.AnswerTime * 100;

            var newLine = string.Format("{0};{1};{2};{3}", first, second, Convert.ToString(third), fourth);
            csv.AppendLine(newLine);
            File.AppendAllText("temp.csv", csv.ToString());
        }

        public static void SaveDataPreview(StructTemplate QUEST)
        {
            var csv = new StringBuilder();


            var first = QUEST.trialCount;
            var second = Inputs.relativContrast;
            var third = Inputs.answer;
            var fourth = Inputs.AnswerTime * 100;

            var newLine = string.Format("{0};{1};{2};{3}", first, second, third, fourth);
            csv.AppendLine(newLine);
            string root = ("C#Programs\\" + QUEST.name);
            if (!Directory.Exists(root))
            {
                Directory.CreateDirectory(root);
            }
            File.AppendAllText("C#Programs\\" + QUEST.name + "\\ANSWER" + Convert.ToString(QUEST.spatialFrequency) + ".csv", csv.ToString());
        }

        //save in the csv file the trial number, the contrast value, if the answer was true or false and the time the user took to answer
        public static void SaveData(StructTemplate QUEST)
        {
            var lines = File.ReadAllLines(@"temp.csv");

            var xml = new XElement("TopElement",
               lines.Select(line => new XElement("Item",
                  line.Split(';')
                      .Select((column, index) => new XElement("Column" + index, column)))));
            
            string root = (QUEST.name+"\\"+Inputs.wavelengthColor+"\\"+Convert.ToString(QUEST.spatialFrequency));

            if (!Directory.Exists(root))
                {
                    Directory.CreateDirectory(root);
                }

            System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(QUEST.name+"\\"+Inputs.wavelengthColor+"\\"+Convert.ToString(QUEST.spatialFrequency));
            int count = dir.GetFiles().Length;

            xml.Save(QUEST.name + "\\" + Inputs.wavelengthColor + "\\" + Convert.ToString(QUEST.spatialFrequency) + "\\" + Convert.ToString(count+1)+".xml");
        }

        // save the first line of the plot file
        public static void SaveSetupPlot(StructTemplate QUEST)
        {
            File.Delete("PLOT.csv");
            var csvH = new StringBuilder();
            var header = string.Format("Trial; Contrast");
            csvH.AppendLine(header);
            var firstLine = string.Format("{0};{1}", 1, Inputs.relativContrast);
            csvH.AppendLine(firstLine);
            File.WriteAllText("PLOT.csv", csvH.ToString());
            System.IO.File.Delete("temp.csv");
        }

        static public double StairCase(StructTemplate QUEST) // used to update the contrast after updating the QUEST procedure with new information
        {
            double intensity;
            if (!Inputs.answer) intensity = Inputs.momentIntensity + Inputs.stairCaseSteps[QUEST.trialCount - 1];
            else intensity = Inputs.momentIntensity - Inputs.stairCaseSteps[QUEST.trialCount - 1];
            if (intensity > 100) intensity = 100;
            if (intensity < 0) intensity = 0;
            return intensity;
        }

        //save the follow data for ploting
        public static void SaveDataPlot(StructTemplate QUEST)
        {
            var csv = new StringBuilder();
            var first = QUEST.trialCount+1;
            var second = Inputs.relativContrast;
            var newLine = string.Format("{0};{1}", first, second);
            csv.AppendLine(newLine);

            File.AppendAllText("PLOT.csv", csv.ToString());
        }

        //save the headers in the csv file
        public static void SaveSetup(StructTemplate QUEST)
        {
            var csv = new StringBuilder();
            var second = "Spatial Frequency: ";
            var third = QUEST.spatialFrequency;
            var fifth = QUEST.eccentricity;

            var Line1 = string.Format("{0};{1}","Name:",QUEST.name);
            var Line2 = string.Format("{0};{1}", second, third);
            var Line3 = string.Format("{0};{1}", "Eccentricity: ", fifth);
            csv.AppendLine(Line1);
            csv.AppendLine(Line2);
            csv.AppendLine(Line3);
            string root = ("C#Programs\\" + QUEST.name);
            if (!Directory.Exists(root))
            {
                Directory.CreateDirectory(root);
            }
            File.AppendAllText("C#Programs\\" + QUEST.name + "\\ANSWER" + Convert.ToString(QUEST.spatialFrequency) + ".csv", csv.ToString());
        }

        public static StructTemplate Restart(StructTemplate QUEST)
        {
            StructTemplate New = new StructTemplate();
            New = QUESTCreate(New);
            New.trialCount = 0;
            New.name = QUEST.name;
            New.eccentricity = QUEST.eccentricity;
            New.spatialFrequency = QUEST.spatialFrequency;
            Inputs.momentIntensity = Inputs.tGuess;

            return QUEST;
        }
    }
}