﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FastBitmapLib;

namespace GraphDemo
{
    public class ImageLib
    {
        static public double[] meshGridLines()
        {
            double add = Inputs.L / (Inputs.Nx - 1);
            double[] lines = new double[Inputs.Nx * Inputs.Nx];
            lines[0] = -Inputs.L / 2;
            for (int j = 1; j < Inputs.Nx; j++)
            {
                lines[j] = lines[j - 1];
            }
            for (int i = 1; i < Inputs.Nx; i++)
            {
                lines[i * Inputs.Nx] = lines[(i - 1) * Inputs.Nx] + add;
                for (int j = 1; j < Inputs.Nx; j++)
                {
                    lines[i * Inputs.Nx + j] = lines[i * Inputs.Nx + j - 1];
                }
            }
            return lines;
        }

        static public double[] meshGridColumns()
        {
            double add = Inputs.L / (Inputs.Nx - 1);
            double[] columns = new double[Inputs.Nx * Inputs.Nx];
            for (int i = 0; i < Inputs.Nx; i++)
            {
                columns[i * Inputs.Nx] = -Inputs.L / 2;
                for (int j = 1; j < Inputs.Nx; j++)
                {
                    columns[i * Inputs.Nx + j] = columns[i * Inputs.Nx + j - 1] + add;
                }
            }

            return columns;
        }

        static public Bitmap createImage0()
        {
            Bitmap image = new Bitmap(1920, 1080);
            Color color;

            using (var fastBitmap = new FastBitmap(image))
            {
                fastBitmap.Lock();
                for (int i = 0; i < 1080; i++)
                {
                    for (int j = 0; j < 1920; j++)
                    {
                        color = Color.FromArgb(0, 0, 0);
                        fastBitmap.SetPixel(j, i, color);
                    }
                }
            }
            return image;
        }

        /*static public double[] multiplyMatrix(int[] x, double factor)
        {
            double[] g = new double[x.Length];
            for (int i = 0; i < x.Length; i++)
            {
                g[i] = x[i] * factor;
            }
            return g;
        }*/

        /*static public double[] multiplyMatrix(double[] x, double factor)
        {
            double[] g = new double[x.Length];
            for (int i = 0; i < x.Length; i++)
            {
                g[i] = x[i] * factor;
            }
            return g;
        }*/


        static public double[] multiplyMatrixSum()
        {
            double[] g = new double[Inputs.x.Length];
            double[] xL = new double[Inputs.x.Length];
            for (int i = 0; i < Inputs.x.Length; i++)
            {
                xL[i] = Inputs.x[i] * Math.Cos(Inputs.angle1 * Math.PI / 180) - Inputs.y[i] * Math.Sin(Inputs.angle1 * Math.PI / 180);
                g[i] = (Inputs.x[i] * (Inputs.cx / Inputs.f) * Inputs.k) + (Inputs.y[i] * (Inputs.cy / Inputs.f) * Inputs.k) + xL[i] * (Inputs.shift / Inputs.f) * Inputs.k;
            }
            return g;
        }

        static public double[] multiplyMatrixSub()
        {
            double[] g = new double[Inputs.x.Length];
            double[] xL = new double[Inputs.x.Length];
            for (int i = 0; i < Inputs.x.Length; i++)
            {
                xL[i] = Inputs.x[i] * Math.Cos(Inputs.angle1 * Math.PI / 180) - Inputs.y[i] * Math.Sin(Inputs.angle1 * Math.PI / 180);
                g[i] = (Inputs.x[i] * (Inputs.cx / Inputs.f) * Inputs.k) + (Inputs.y[i] * (Inputs.cy / Inputs.f) * Inputs.k) - xL[i] * (Inputs.shift / Inputs.f) * Inputs.k;
            }
            return g;
        }


        static public double[] wrapTo2Pi(double[] x, int lines, int columns)
        {
            double[] g = new double[lines * columns];
            for (int i = 0; i < lines; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    g[i * columns + j] = (x[i * 1920 + j]+10000) % (2 * Math.PI);
                }
            }
            return g;
        }


        /*static public double[,] exchange(double[,] grL, double[,] grR)
        {
            int auxi = 0, conti = 0;
            int auxj = 0, contj = 0;
            double[,] check = new double[grL.GetLength(0), grL.GetLength(1)];
            for (int i = 0; i < grL.GetLength(0); i++)
            {
                conti++;
                if (conti == 51) auxi = 1;
                if (conti == 101) { auxi = 0; conti = 0; }
                for (int j = 0; j < grL.GetLength(1); j++)
                {
                    if (contj == 51) auxj = 1;
                    if (contj == 101) { auxj = 0; contj = 0; }
                    if (auxi + auxj == 1) check[i, j] = grR[i, j];
                    else check[i, j] = grL[i, j];
                }
            }
            return check;
        }*/

        static public double[] exchange(double[] grL, double grLFactor, double[] grR, double grRFactor)
        {
            double[] check = new double[grL.Length];
            for (int i = 0; i < grL.Length; i++)
            {
                //if (Inputs.rndPattern[i]) check[i] = grR[i] * grRFactor;
                if (Inputs.chkrBrdPattern[i]) check[i] = grR[i] * grRFactor;
                else check[i] = grL[i] * grLFactor;
            }
            return check;
        }

        static public double findMax(double[] x)
        {
            double max = 0;
            for (int i = 0; i < x.Length; i++)
            {
                if (x[i] > max) max = x[i];
            }
            return max;
        }


        static public byte[] toByte(double[] x)
        {
            byte[] xByte = new byte[x.Length];
            for (int i = 0; i < x.Length; i++)
            {
                xByte[i] = Convert.ToByte(x[i]);
            }
            return xByte;
        }


        static public Bitmap imageFill(byte[] x)
        {
            Bitmap image = new Bitmap(1920, 1080);
            Color color;

            using (var fastBitmap = new FastBitmap(image))
            {
                fastBitmap.Lock();
                for (int i = 0; i < 1080; i++)
                {
                    for (int j = 0; j < 1920; j++)
                    {
                        color = Color.FromArgb(x[i * 1920 + j], x[i * 1920 + j], x[i * 1920 + j]);
                        fastBitmap.SetPixel(j, i, color);
                    }
                }
            }
            return image;
        }

        static public bool[] randomPattern()
        {
            System.Random rnd = new System.Random();

            bool[] x = new bool[1080 * 1920];
            int i = 0;
            int aux;
            while (i < (x.Length / 2))
            {
                aux = rnd.Next(x.Length);
                if (x[aux] != true)
                {
                    x[aux] = true;
                    i++;
                }
            }
            return x;
        }

        static public bool[] checkerBoardPattern()
        {
            bool[] x = new bool[1080 * 1920];
            for (int i = 0; i < x.Length; i++)
            {
                if ((i % 2) == 0)
                    x[i] = true;
                else
                    x[i] = false;
            }
            return x;
        }
        /*
        static public double[] XlCreate()
        {
            double[] xL = new double[Inputs.x.Length];

            for (int i = 0; i < Inputs.x.Length; i++)
            {
                xL[i] = Inputs.x[i] * Math.Cos(Inputs.angle1 * Math.PI / 180) - Inputs.y[i] * Math.Sin(Inputs.angle1 * Math.PI / 180);
            }
            return xL;
        }

        static public double[] gsCreate(int[] x, double blazecommonshift)
        {
            double[] gs = new double[x.Length];

            for (int i = 0; i < x.Length; i++)
            {
                gs[i] = x[i] * blazecommonshift / 0.59;
            }
            return gs;
        }
        static public double[] gsSub(double[] gs, double[] g)
        {
            double[] gnew = new double[gs.Length];
            for (int i = 0; i < gs.Length; i++)
            {
                gnew[i] = gs[i] - g[i];
            }
            return gnew;
        }

        static public double[] gsSum(double[] gs, double[] g)
        {
            double[] gnew = new double[gs.Length];
            for (int i = 0; i < gs.Length; i++)
            {
                gnew[i] = gs[i] + g[i];
            }
            return gnew;
        }*/
    }
}