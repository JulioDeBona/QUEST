﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GraphDemo
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Thread t1 = ThreadForm1();
            Thread t2 = ThreadForm2();
            t1.SetApartmentState(ApartmentState.STA);
            t2.Start();
            t1.Start();
        }
        public static Thread ThreadForm1()
        {
            Thread t = new Thread(() =>
            {
                Application.Run(new GraphDemo());

            });
            return t;
        }
        public static Thread ThreadForm2()
        {
            Thread t = new Thread(() =>
            {
                Application.Run(new External());

            });
            return t;
        }
    }
}
