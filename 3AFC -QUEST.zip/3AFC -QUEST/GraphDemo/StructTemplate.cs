﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphDemo.QUEST
{
    class StructTemplate
    {
        public bool updatePdf;
        public bool warnPdf;
        public bool normalizePdf;
        public double tGuess;
        public double tGuessSd;
        //public double pThreshold;
        public double beta;
        public double delta;
        public double gamma;
        public double grain;
        public double dim;
        public int[] i;
        public double[] x;
        public double[] pdf;
        public int[] i2;
        public double[] x2;
        public double[] p2;
        public double xThreshold;
        public double[,] s2;
        public double[,] pdf2;
        public int trialCount;
        public double[] intensity;
        public bool[] response;
        public double quantileOrder;
        public string name, eccentricity;
        public double spatialFrequency;
    }
}
