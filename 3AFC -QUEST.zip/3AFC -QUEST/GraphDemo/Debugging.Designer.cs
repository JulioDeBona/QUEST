﻿namespace GraphDemo
{
    partial class Debugging
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.SFBox = new System.Windows.Forms.TextBox();
            this.NameLabel = new System.Windows.Forms.Label();
            this.contrastBox = new System.Windows.Forms.TextBox();
            this.wavelengthBox = new System.Windows.Forms.TextBox();
            this.EccentricityLabel = new System.Windows.Forms.Label();
            this.SFLabel = new System.Windows.Forms.Label();
            this.domainUpDown1 = new System.Windows.Forms.DomainUpDown();
            this.btnPlot = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 23);
            this.label5.TabIndex = 37;
            this.label5.Text = "DIRECTION:";
            // 
            // SFBox
            // 
            this.SFBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.SFBox.Location = new System.Drawing.Point(204, 99);
            this.SFBox.Name = "SFBox";
            this.SFBox.Size = new System.Drawing.Size(128, 30);
            this.SFBox.TabIndex = 34;
            this.SFBox.TextChanged += new System.EventHandler(this.SFBox_TextChanged);
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameLabel.Location = new System.Drawing.Point(12, 99);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(173, 23);
            this.NameLabel.TabIndex = 35;
            this.NameLabel.Text = "SPATIAL FREQUENCY:";
            // 
            // contrastBox
            // 
            this.contrastBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.contrastBox.Location = new System.Drawing.Point(204, 55);
            this.contrastBox.Name = "contrastBox";
            this.contrastBox.Size = new System.Drawing.Size(128, 30);
            this.contrastBox.TabIndex = 33;
            this.contrastBox.TextChanged += new System.EventHandler(this.contrastBox_TextChanged);
            // 
            // wavelengthBox
            // 
            this.wavelengthBox.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.wavelengthBox.Location = new System.Drawing.Point(204, 12);
            this.wavelengthBox.Name = "wavelengthBox";
            this.wavelengthBox.Size = new System.Drawing.Size(128, 30);
            this.wavelengthBox.TabIndex = 32;
            this.wavelengthBox.TextChanged += new System.EventHandler(this.wavelengthBox_TextChanged);
            // 
            // EccentricityLabel
            // 
            this.EccentricityLabel.AutoSize = true;
            this.EccentricityLabel.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.EccentricityLabel.Location = new System.Drawing.Point(12, 55);
            this.EccentricityLabel.Name = "EccentricityLabel";
            this.EccentricityLabel.Size = new System.Drawing.Size(97, 23);
            this.EccentricityLabel.TabIndex = 31;
            this.EccentricityLabel.Text = "CONTRAST:";
            // 
            // SFLabel
            // 
            this.SFLabel.AutoSize = true;
            this.SFLabel.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.SFLabel.Location = new System.Drawing.Point(12, 12);
            this.SFLabel.Name = "SFLabel";
            this.SFLabel.Size = new System.Drawing.Size(123, 23);
            this.SFLabel.TabIndex = 30;
            this.SFLabel.Text = "WAVELENGTH:";
            // 
            // domainUpDown1
            // 
            this.domainUpDown1.Location = new System.Drawing.Point(204, 148);
            this.domainUpDown1.Name = "domainUpDown1";
            this.domainUpDown1.Size = new System.Drawing.Size(128, 20);
            this.domainUpDown1.TabIndex = 38;
            this.domainUpDown1.Text = "domainUpDown1";
            // 
            // btnPlot
            // 
            this.btnPlot.BackColor = System.Drawing.Color.Lime;
            this.btnPlot.Font = new System.Drawing.Font("Calibri", 13.8F);
            this.btnPlot.Location = new System.Drawing.Point(115, 185);
            this.btnPlot.Name = "btnPlot";
            this.btnPlot.Size = new System.Drawing.Size(113, 53);
            this.btnPlot.TabIndex = 39;
            this.btnPlot.Text = "PRINT";
            this.btnPlot.UseVisualStyleBackColor = false;
            this.btnPlot.Click += new System.EventHandler(this.btnPlot_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 267);
            this.Controls.Add(this.btnPlot);
            this.Controls.Add(this.domainUpDown1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.SFBox);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.contrastBox);
            this.Controls.Add(this.wavelengthBox);
            this.Controls.Add(this.EccentricityLabel);
            this.Controls.Add(this.SFLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox SFBox;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.TextBox contrastBox;
        private System.Windows.Forms.TextBox wavelengthBox;
        private System.Windows.Forms.Label EccentricityLabel;
        private System.Windows.Forms.Label SFLabel;
        private System.Windows.Forms.DomainUpDown domainUpDown1;
        private System.Windows.Forms.Button btnPlot;
    }
}